//
//  DetailVC.swift
//  ageCalculator
//
//  Created by Vijay on 01/06/19.
//  Copyright © 2019 Disha Technology. All rights reserved.
//

import UIKit

class DetailVC: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    
    //IBOutlets
    @IBOutlet weak var tablee:UITableView!
    
    
    let date = Date()
    let formatter = DateFormatter()
    var years = 00
    var months = 00
    var days = 00
    
    var nextDay = 00
    var nextMonths = 00
    
    var extraYears = 0
    var extraMonths = 0
    var extraWeeks = 0
    var extraDays = 0
    var extraHours = 0
    var extraMinutes = 0
    var extraSeconds = 0
    
    var birthDate:Date!
    var birthdateStr = ""
    
    var datePickerFrom  = ""
    
    var today:Date!
    var todayStr = ""
    var todayWeekDay = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        hideKeyboardWhenTappedAround()
        self.tablee.reloadData()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    @IBAction func btnSettingClciked(_ sender: Any) {

        let vc = SettingVC(nibName: "SettingVC", bundle: nil)
        self.present(vc, animated: true, completion: nil)

    }
    
    @IBAction func btnBackClicked(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //UITableView Delegate and Datasource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            let cell4 = tableView.dequeueReusableCell(withIdentifier: "cell4") as! ageCell
            cell4.yearLbl.text = "\(self.years)"
            cell4.monthsCell.text = "\(self.months)"
            cell4.daysLbl.text = "\(self.days)"
            return cell4
        } else if indexPath.row == 1 {
            let cell5 = tableView.dequeueReusableCell(withIdentifier: "cell5") as! nextBirthCell
            cell5.daysLbl.text = "\(self.nextDay)"
            cell5.monthsLbl.text = "\(self.nextMonths)"
            return cell5
        } else if indexPath.row == 2 {
            let cell6 = tableView.dequeueReusableCell(withIdentifier: "cell6") as! extraCell
            cell6.totalYearLbl.text = "\(self.extraYears)"
            cell6.totalMonthsLbl.text = "\(self.extraMonths)"
            cell6.totalDaysLbl.text = "\(self.extraDays)"
            cell6.totalWeeksLbl.text = "\(self.extraWeeks)"
            cell6.totalHoursLbl.text = "\(self.extraHours)"
            cell6.totalMinLbl.text = "\(self.extraMinutes)"
            cell6.totalSecondsLbl.text = "\(self.extraSeconds)"
            return cell6
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        return cell!
    }

}
