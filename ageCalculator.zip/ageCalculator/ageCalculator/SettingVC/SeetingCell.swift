//
//  SeetingCell.swift
//  BMI Calculator
//
//  Created by Vijay on 30/05/19.
//  Copyright © 2019 Rohit. All rights reserved.
//

import UIKit

class SeetingCell: UITableViewCell {

    @IBOutlet var lblTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
