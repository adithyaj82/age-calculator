//
//  SettingVC.swift
//  BMI Calculator
//  Created by Vijay on 29/05/19.
//  Copyright © 2019 Rohit. All rights reserved.
//

import UIKit
import MessageUI

class SettingVC: UIViewController  ,UITableViewDataSource, UITableViewDelegate , MFMailComposeViewControllerDelegate {
    
    var Arryitems = ["Age Calculator info", "Support", "More apps", "Share with Friend"]
   
    @IBOutlet var tblData: UITableView!
    
    override func viewDidLoad() {

        super.viewDidLoad()
        self.tblData.register(UINib(nibName: "SeetingCell", bundle: nil), forCellReuseIdentifier: "SeetingCell")
        self.tblData.reloadData()
        
    }

    //MARK: - table method
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.Arryitems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SeetingCell? = tableView.dequeueReusableCell(withIdentifier:"SeetingCell") as? SeetingCell
        
        if cell == nil{
            tableView.register(UINib.init(nibName: "SeetingCell", bundle: nil), forCellReuseIdentifier: "SeetingCell")
        }
        
        cell?.lblTitle.text = "\(self.Arryitems[indexPath.row])"
        
        return cell!
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            let vc = BMIinfoVC(nibName: "BMIinfoVC", bundle: nil)
            self.present(vc, animated: true, completion: nil)
        }

        if indexPath.row == 1 {
            
            if MFMailComposeViewController.canSendMail() {
                let mail = MFMailComposeViewController()
                mail.mailComposeDelegate = self
                mail.setToRecipients(["xyz@gmail.com"])
                mail.setSubject("")
                mail.setMessageBody("", isHTML: true)
                present(mail, animated: true, completion: nil)
            } else {
                print("Cannot send mail")
                // give feedback to the user
            }
        }
        
        if indexPath.row == 2 {
            UIApplication.shared.open(URL(string: "https://itunes.apple.com/in/developer/bhut-vijay/id1463820419")!, options: [:]) { (open) in
                print("open : \(open)")
            }
        }
        
        if indexPath.row == 3{
            let items = [URL(string: "https://itunes.apple.com/in/developer/bhut-vijay/id1463820419")!]
            let ac = UIActivityViewController(activityItems: items, applicationActivities: nil)
            present(ac, animated: true)

        }
        
    }
    
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        switch result.rawValue {
        case MFMailComposeResult.cancelled.rawValue:
            print("Cancelled")
        case MFMailComposeResult.saved.rawValue:
            print("Saved")
        case MFMailComposeResult.sent.rawValue:
            print("Sent")
        case MFMailComposeResult.failed.rawValue:
            print("Error: \(String(describing: error?.localizedDescription))")
        default:
            break
        }
        controller.dismiss(animated: true, completion: nil)
    }

    
    @IBAction func btnBackClicked(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
