//
//  webviewVC.swift
//  BMI Calculator
//
//  Created by Vijay on 30/05/19.
//  Copyright © 2019 Rohit. All rights reserved.
//

import UIKit

class webviewVC: UIViewController {
    
    @IBOutlet weak var webView: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()

        let url = URL (string: "http://embstore.happyindustrialsolutions.com/support")
        let requestObj = URLRequest(url: url!)
        self.webView.loadRequest(requestObj)

    }


}
