//
//  VCCells.swift
//  ageCalculator
//
//  Created by Yash Rathod on 23/04/19.
//  Copyright © 2019 Disha Technology. All rights reserved.
//

import Foundation
import UIKit

class todayCell:UITableViewCell {
    
    @IBOutlet weak var txt1:UITextField!
    @IBOutlet weak var btnCalender:UIButton!
    @IBOutlet weak var weekDayLbl:UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}

class dobCell:UITableViewCell {
    
    @IBOutlet weak var txt1:UITextField!
    @IBOutlet weak var btnCalender:UIButton!
    @IBOutlet weak var weekDayLbl:UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
}

class calculateBtnCell:UITableViewCell {
    
    @IBOutlet weak var calculateBtn:UIButton!
    @IBOutlet weak var clearBtn:UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
class ageCell:UITableViewCell {
    
    @IBOutlet weak var yearLbl:UILabel!
    @IBOutlet weak var monthsCell:UILabel!
    @IBOutlet weak var daysLbl:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}


class nextBirthCell:UITableViewCell {
    
    @IBOutlet weak var monthsLbl:UILabel!
    @IBOutlet weak var daysLbl:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}


class extraCell:UITableViewCell {
    
    @IBOutlet weak var totalYearLbl:UILabel!
    @IBOutlet weak var totalMonthsLbl:UILabel!
    @IBOutlet weak var totalDaysLbl:UILabel!
    @IBOutlet weak var totalWeeksLbl:UILabel!
    @IBOutlet weak var totalHoursLbl:UILabel!
    @IBOutlet weak var totalMinLbl:UILabel!
    @IBOutlet weak var totalSecondsLbl:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
