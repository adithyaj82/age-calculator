//
//  ViewController.swift
//  ageCalculator
//
//  Created by Yash Rathod on 23/04/19.
//  Copyright © 2019 Disha Technology. All rights reserved.
//

import UIKit

var globalView:UIView!

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,DatePickerActionSheetDelegate {
    
    
    var datePickerActionSheet: DatePickerActionSheet?
    
    //IBOutlets
    @IBOutlet weak var tablee:UITableView!
    @IBOutlet weak var datepickerView: UIView!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    
    let date = Date()
    let formatter = DateFormatter()
    var years = 00
    var months = 00
    var days = 00
    
    var nextDay = 00
    var nextMonths = 00
    
    var extraYears = 0
    var extraMonths = 0
    var extraWeeks = 0
    var extraDays = 0
    var extraHours = 0
    var extraMinutes = 0
    var extraSeconds = 0
    
    var birthDate:Date!
    var birthdateStr = ""
    
    var datePickerFrom  = ""
    
    var today:Date!
    var todayStr = ""
    var todayWeekDay = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        datePickerActionSheet = DatePickerActionSheet()
        datePickerActionSheet?.delegate = self
        formatter.dateFormat = "dd - MM - yyyy"
        hideKeyboardWhenTappedAround()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.datepickerView.isHidden = true
    }
    
    @IBAction func doneBtn(_ sender:UIButton) {
        
        if self.datePickerFrom == "todayDate" {
            let date = self.datePicker.date as NSDate
            let formatterr = DateFormatter()
            formatterr.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let myString = formatterr.string(from: date as Date)
            let yourDate = formatterr.date(from: myString)
            formatterr.dateFormat = "dd - MM - yyyy"
            let myStringafd = formatterr.string(from: yourDate!)
            let ind = IndexPath(row: 0, section: 0)
            let cell2 = self.tablee.cellForRow(at: ind) as! todayCell
            cell2.weekDayLbl.text = date.dayOfTheWeek()
            cell2.txt1.text = myStringafd
            self.today = date as Date
            self.todayStr = myStringafd
            self.datepickerView.isHidden = true
        } else if self.datePickerFrom == "birthday" {
            let date = self.datePicker.date as NSDate
            let formatterr = DateFormatter()
            formatterr.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let myString = formatterr.string(from: date as Date)
            let yourDate = formatterr.date(from: myString)
            formatterr.dateFormat = "dd - MM - yyyy"
            let myStringafd = formatterr.string(from: yourDate!)
            let ind = IndexPath(row: 1, section: 0)
            let cell2 = self.tablee.cellForRow(at: ind) as! dobCell
            cell2.weekDayLbl.text = date.dayOfTheWeek()
            cell2.txt1.text = myStringafd
            self.birthDate = date as Date
            self.birthdateStr = myStringafd
            self.datepickerView.isHidden = true
        }
       
    }
    @IBAction func cancel(_ sender:UIButton) {
        self.datepickerView.isHidden = true
    }
    @IBAction func btnCalculateHandler(_ sender: UIButton){
        
        //Check for Date is enterd or not
        let ind2 = IndexPath(row: 1, section: 0)
        let cell2 = self.tablee.cellForRow(at: ind2) as! dobCell
        if cell2.txt1.text == "" {
            self.showAlert(title: "Message", message: "Please enter birthdate")
            return
        }

        //If Entered, check for date is correct or not
        let birthDate = self.birthDate!
        let today = self.today ?? Date()
        if birthDate >= today {
            self.showAlert(title: "Message", message: "Please enter a valid date")
            return
        }
    
        
        //Break Down the date
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day], from: birthDate, to: today)
        let ageYears = components.year
        let ageMonths = components.month
        let ageDays = components.day
        
        //Break down today date for Next birthday calculation
        let todayComp = calendar.dateComponents([.year,.month,.day], from: today)
        let todayYear = todayComp.year
        let todayMonth = todayComp.month
        
        //Next Birthdate Calculation
        var birthComp = calendar.dateComponents([.year,.month,.day], from: birthDate)
        let birthmonth = birthComp.month
        if birthmonth! <= todayMonth! {
            birthComp.year = todayYear! + 1
        } else {
            birthComp.year = todayYear
        }
        let calculate = calendar.dateComponents([.month,.day], from: todayComp, to: birthComp)
        let ind4 = IndexPath(row: 4, section: 0)
        
        
        //Assign Age to UILabel
        let ind = IndexPath(row: 3, section: 0)
        
        //Assign To extra
        let indd = IndexPath(row: 5, section: 0)
        self.extraYears = ageYears!
        
        let months = ageYears! * 12
        self.extraMonths = months
        
        let weeks = months * 4
        self.extraWeeks = weeks
        
        let days = weeks * 7
        self.extraDays = days
        
        let hours = days * 24
        self.extraHours = hours
        
        let minutes = hours * 60
        self.extraMinutes = minutes
        
        let secondss = minutes * 60
        self.extraSeconds = secondss
        
        
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DetailVC") as! DetailVC
        
        nextViewController.years = ageYears!
        nextViewController.months = ageMonths!
        nextViewController.days =  ageDays!
        
        nextViewController.nextMonths = calculate.month!
        nextViewController.nextDay = calculate.day!
    
        
        nextViewController.extraYears = self.extraYears
        nextViewController.extraMonths = self.extraMonths
        nextViewController.extraWeeks = self.extraWeeks
        nextViewController.extraDays = self.extraDays
        nextViewController.extraHours = self.extraHours
        nextViewController.extraMinutes = self.extraMinutes
        nextViewController.extraSeconds = self.extraSeconds

        self.present(nextViewController, animated:true, completion:nil)

        
    }
    
    @IBAction func btnSettingClciked(_ sender: Any) {
        
        let vc = SettingVC(nibName: "SettingVC", bundle: nil)
        self.present(vc, animated: true, completion: nil)
        
    }
    @objc func showBDate() {
        self.datePickerFrom = "birthday"
        //presentDatePickerActionSheet()
        self.datepickerView.isHidden = false
        
        
    }
    @objc func showDate() {
        self.datePickerFrom = "todayDate"
        //presentDatePickerActionSheet()
        self.datepickerView.isHidden = false
    }
    
    //UITableView Delegate and Datasource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "cell1") as! todayCell
            cell1.txt1.text = formatter.string(from: date)
            cell1.weekDayLbl.text = (date as NSDate).dayOfTheWeek()
            cell1.btnCalender.addTarget(self, action: #selector(showDate), for: .touchUpInside)
            globalView = cell1.btnCalender
            return cell1
        } else if indexPath.row == 1 {
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "cell2") as! dobCell
            cell2.txt1.text = self.birthdateStr
            cell2.btnCalender.addTarget(self, action: #selector(showBDate), for: .touchUpInside)
            globalView = cell2.btnCalender
            return cell2
        } else if indexPath.row == 2 {
            let cell3 = tableView.dequeueReusableCell(withIdentifier: "cell3") as! calculateBtnCell
            cell3.calculateBtn.addTarget(self, action: #selector(btnCalculateHandler(_:)), for: .touchUpInside)
            return cell3
        }
        
        else if indexPath.row == 3 {
            let cell4 = tableView.dequeueReusableCell(withIdentifier: "cell4") as! ageCell
            cell4.yearLbl.text = "\(self.years)"
            cell4.monthsCell.text = "\(self.months)"
            cell4.daysLbl.text = "\(self.days)"
            return cell4
        } else if indexPath.row == 4 {
            let cell5 = tableView.dequeueReusableCell(withIdentifier: "cell5") as! nextBirthCell
            cell5.daysLbl.text = "\(self.nextDay)"
            cell5.monthsLbl.text = "\(self.nextMonths)"
            return cell5
        } else if indexPath.row == 5 {
            let cell6 = tableView.dequeueReusableCell(withIdentifier: "cell6") as! extraCell
            cell6.totalYearLbl.text = "\(self.extraYears)"
            cell6.totalMonthsLbl.text = "\(self.extraMonths)"
            cell6.totalDaysLbl.text = "\(self.extraDays)"
            cell6.totalWeeksLbl.text = "\(self.extraWeeks)"
            cell6.totalHoursLbl.text = "\(self.extraHours)"
            cell6.totalMinLbl.text = "\(self.extraMinutes)"
            cell6.totalSecondsLbl.text = "\(self.extraSeconds)"
            return cell6
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
        
    }
    //Date selected from UIDatapicker
    func onDidDateSelected(date: NSDate?) {
        if self.datePickerFrom == "todayDate" {
            self.today = date! as Date
        } else if self.datePickerFrom == "birthday" {
            let formatterr = DateFormatter()
            formatterr.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let myString = formatterr.string(from: date! as Date)
            let yourDate = formatterr.date(from: myString)
            formatterr.dateFormat = "dd - MM - yyyy"
            let myStringafd = formatterr.string(from: yourDate!)
            let ind = IndexPath(row: 1, section: 0)
            let cell2 = self.tablee.cellForRow(at: ind) as! dobCell
            cell2.weekDayLbl.text = date?.dayOfTheWeek()
            cell2.txt1.text = myStringafd
            self.birthDate = date! as Date
            self.birthdateStr = myStringafd
        }
    }
}
